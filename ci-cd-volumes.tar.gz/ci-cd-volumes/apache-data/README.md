# cicd-demo
A simple web page to demonstrate a basic CI/CD pipeline